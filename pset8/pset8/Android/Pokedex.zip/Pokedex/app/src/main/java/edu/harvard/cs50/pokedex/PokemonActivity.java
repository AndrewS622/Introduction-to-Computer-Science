package edu.harvard.cs50.pokedex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class PokemonActivity extends AppCompatActivity {
    private TextView nameTextView;
    private TextView numberTextView;
    private TextView type1TextView;
    private TextView type2TextView;
    private TextView descriptionTextView;
    private ImageView pokemonSprite;
    private String url;
    private boolean caught;
    private String name;
    private String nameCap;
    private RequestQueue requestQueue;
    private List<String> ButtonText = new ArrayList<>();
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon);

        requestQueue = Volley.newRequestQueue(getApplicationContext());
        name = getIntent().getStringExtra("name");
        nameCap = name.substring(0, 1).toUpperCase() + name.substring(1);
        url = getIntent().getStringExtra("url");
        SharedPreferences caughtMap = getSharedPreferences("caughtMap", Context.MODE_PRIVATE);
        Boolean caught = caughtMap.getBoolean(name, false);
        nameTextView = findViewById(R.id.pokemon_name);
        numberTextView = findViewById(R.id.pokemon_number);
        type1TextView = findViewById(R.id.pokemon_type1);
        type2TextView = findViewById(R.id.pokemon_type2);
        pokemonSprite = findViewById(R.id.pokemon_sprite);
        descriptionTextView = findViewById(R.id.pokemon_description);
        button = findViewById(R.id.CatchButton);
        ButtonText.add("Catch");
        ButtonText.add("Release");
        int caughtInt = caught ? 1 : 0;
        button.setText(ButtonText.get(caughtInt));

        load();
    }

    private class DownloadSpriteTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                return BitmapFactory.decodeStream(url.openStream());
            }
            catch (IOException e) {
                Log.e("cs50", "Download sprite error", e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            pokemonSprite.setImageBitmap(bitmap);
        }
    }

    public void load() {
        type1TextView.setText("");
        type2TextView.setText("");

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    nameTextView.setText(response.getString("name").substring(0, 1).toUpperCase()
                            + response.getString("name").substring(1));
                    numberTextView.setText(String.format("#%03d", response.getInt("id")));

                    JSONArray typeEntries = response.getJSONArray("types");
                    for (int i = 0; i < typeEntries.length(); i++) {
                        JSONObject typeEntry = typeEntries.getJSONObject(i);
                        int slot = typeEntry.getInt("slot");
                        String type = typeEntry.getJSONObject("type").getString("name");
                        String typeCap = type.substring(0,1).toUpperCase() + type.substring(1);

                        if (slot == 1) {
                            type1TextView.setText(typeCap);
                        }
                        else if (slot == 2) {
                            type2TextView.setText(typeCap);
                        }
                    }
                    JSONObject spriteEntry = response.getJSONObject("sprites");
                    String image_url = spriteEntry.getString("front_default");

                    new DownloadSpriteTask().execute(image_url);

                    String description_url = response.getJSONObject("species").getString("url");
                    addDescription(description_url);
                } catch (JSONException e) {
                    Log.e("cs50", "Pokemon json error", e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("cs50", "Pokemon details error", error);
            }
        });

        requestQueue.add(request);
    }

    public void addDescription(final String description_url) {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, description_url,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    String language;
                    JSONArray Entries = response.getJSONArray("flavor_text_entries");
                    int i = 0;
                    do {
                        JSONObject Entry = Entries.getJSONObject(i);
                        String description = Entry.getString("flavor_text");
                        language = Entry.getJSONObject("language").getString("name");
                        description = description.replace("\n", " ");
                        descriptionTextView.setText(description);
                        i += 1;
                    } while (!language.equals("en"));
                } catch (JSONException e) {
                    Log.e("cs50", "Pokemon description error", e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("cs50", "Pokemon description details error", error);
            }
        });
        requestQueue.add(request);
    }

    public void toggleCatch(View view) {
        SharedPreferences caughtMap = getSharedPreferences("caughtMap", Context.MODE_PRIVATE);
        Boolean caught = !caughtMap.getBoolean(name, false);
        int caughtInt = caught ? 1 : 0;
        button.setText(ButtonText.get(caughtInt));
        SharedPreferences.Editor editor = caughtMap.edit();
        editor.putBoolean(nameCap, caught);
        editor.apply();

    }
}