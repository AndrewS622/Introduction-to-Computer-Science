package edu.harvard.cs50.notes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    SharedPreferences ids;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private NotesAdapter adapter;
    public static NotesDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ids = getSharedPreferences("ID", Context.MODE_PRIVATE);

        database = Room
            .databaseBuilder(getApplicationContext(), NotesDatabase.class, "notes")
            .allowMainThreadQueries()
            .build();

        recyclerView = findViewById(R.id.recycler_view);
        layoutManager = new LinearLayoutManager(this);
        adapter = new NotesAdapter();

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.add_note_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database.noteDao().create();
                SharedPreferences.Editor editor = ids.edit();
                List<Note> notes = database.noteDao().getAll();
                for (int i = 0; i < notes.size(); i++) {
                    System.out.println("The note at position " + i + " has ID " + notes.get(i).id);
                }
                int newID = notes.get(notes.size() - 1).id;
                editor.putInt(Integer.toString(notes.size() - 1), newID);
                editor.apply();
                adapter.reload();
            }
        });

        SwipeToDelete swipeToDelete = new SwipeToDelete(this) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();

                int id = ids.getInt(Integer.toString(position), 0);

                SharedPreferences.Editor editor = ids.edit();
                List<Note> notes = database.noteDao().getAll();
                for (int i = position; i < notes.size() - 1; i++) {
                    editor.putInt(Integer.toString(i), notes.get(i + 1).id);
                    editor.apply();
                }

                MainActivity.database.noteDao().delete(id);
                adapter.reload();
            }
        };
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(swipeToDelete);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    protected void onResume() {
        super.onResume();

        adapter.reload();
    }
}
