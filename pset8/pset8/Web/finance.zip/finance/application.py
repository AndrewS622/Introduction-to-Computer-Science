import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # get all stocks owned by user
    stocks = db.execute("SELECT * FROM stocks WHERE id = :id", id = session["user_id"])

    # look up current value and name of each stock and append to vector, along with total value of stock
    stockPrices = []
    stockNames = []
    for stock in stocks:
        stockInfo = lookup(stock["stock"])
        stock['name'] = stockInfo["name"]
        stock['price'] = stockInfo["price"]
        stock['value'] = usd(stock["shares"] * stockInfo["price"])

    # sort alphabetically
    stocks = sorted(stocks, key = lambda i: i["name"])

    # get current cash owned by user
    cash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])
    cash = cash[0]["cash"]

    # get total value of current holdings
    holdings = cash + sum([stocks[i]["price"] * stocks[i]["shares"] for i in range(len(stocks))])

    # convert prices to formatted strings
    for stock in stocks:
        stock['price'] = usd(stock['price'])

    # render template
    return render_template("index.html", stocks = stocks, cash = usd(cash), holdings = usd(holdings))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        stock = lookup(request.form.get("symbol"))
        num = request.form.get("shares")

        # check if symbol is present
        if not request.form.get("symbol"):
            return apology("you must provide a stock symbol")

        # check if stock is present
        if not stock:
            return render_template("nostock.html", symbol = request.form.get("symbol"))

        # check if number of stocks is present
        if not num:
            return apology("you must provide a number of stocks")

        # check for non-integer or negative number of shares
        if not num.isdigit():
            return apology("you must provide a non-negative integer number of stocks")

        num = int(num)

        # find current amount of cash
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])
        cash = float(cash[0]["cash"])

        # find total cost
        cost = stock["price"] * num

        # ensure enough money is available
        if cost > cash:
            return apology("not enough cash to complete transaction", 405)

        # make transaction in transaction table
        db.execute("INSERT INTO transactions ('id', 'cash0', 'stock', 'cash', 'number', 'price', 'time') VALUES (:id, :cash0, :stock, :cash, :number, :price, datetime('now'))",
            id = session["user_id"], cash0 = cash, stock = stock["symbol"], cash = cash - cost, number = num, price = stock["price"])

        # update cash in user table
        db.execute("UPDATE users SET cash = :cashnew WHERE id = :id", cashnew = cash-cost, id = session["user_id"])

        # check if user has already puchased this stock before
        curStocks = db.execute("SELECT * FROM stocks WHERE id = :id and stock = :stock", id = session["user_id"], stock = stock["symbol"])
        if not curStocks:
            db.execute("INSERT INTO stocks ('id', 'stock', 'shares') VALUES (:id, :stock, :shares)", id = session["user_id"], stock = stock["symbol"], shares = num)

        else:
            db.execute("UPDATE stocks SET shares = :shares WHERE id = :id AND stock = :stock", id = session["user_id"], stock = stock["symbol"], shares = num + curStocks[0]["shares"])

        return redirect("/")

    else:
        return render_template("buy.html")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    # get all transactions for user
    stocks = db.execute("SELECT * FROM transactions WHERE id = :id", id = session["user_id"])

    # return apology if user has no transactions
    if not stocks:
        return apology("You have no transactions. Visit the Buy page to get started", 403)

    # vectors used for making plot of cash vs. time
    x = []
    y = []

    # extract cash and time, append on type buy or sell
    for stock in stocks:
        x.append(stock["time"])
        y.append(stock["cash"])
        if stock["cash0"] > stock["cash"]:
            stock["type"] = "buy"
        else:
            stock["type"] = "sell"

    # reverse stocks so newest is at the top
    stocks.reverse()
    if len(x) > 20:
        x = x[1:20]
        y = y[1:20]

    return render_template("history.html", stocks = stocks, x = x, y = y)

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/passwordchange", methods=["GET", "POST"])
@login_required
def passwordchange():
    """Change password"""
    if request.method == "POST":
        # Get inputs
        old = request.form.get("current")
        new = request.form.get("new")
        confirm = request.form.get("confirmation")

        # Make sure all fields were filled
        if not old:
            return apology("you must enter your current password", 403)

        elif not new:
            return apology("you must provide a new password", 403)

        elif not confirm:
            return apology("you must confirm your new password", 403)

        # Query database and make sure password hashes match
        rows = db.execute("SELECT * FROM users WHERE id = :id", id = session["user_id"])

        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], old):
            return apology("incorrect password")

        # Make sure submitted passwords are the same
        if new != confirm:
            return apology("passwords do not match")

        # Make sure password satisfies criteria: at least 8 characters, at least one capital, one lowercase, and one number
        if not (any(s.isupper() for s in new) and any(s.islower() for s in new) and any(s.isdigit() for s in new) and len(new) >=8):
            return apology("password must contain at least one number, one capital, and one lowercase letter and must be at least 8 characters long")

        # Update table with new password
        db.execute("UPDATE users SET hash = :hash WHERE id = :id", hash = generate_password_hash(new), id = session["user_id"])

        return redirect("/")

    else:
        return render_template("passwordchange.html")

@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":
        if not request.form.get("symbol"):
            return apology("you must provide a stock symbol", 403)

        stock = lookup(request.form.get("symbol"))
        if not stock:
            return render_template("nostock.html", symbol = request.form.get("symbol"))

        return render_template("quoted.html", name = stock["name"], price = stock["price"], symbol = stock["symbol"])

    else:
        return render_template("quote.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        elif not request.form.get("confirmation"):
            return apology("must confirm password for confirmation", 403)

        password = request.form.get("password")

         # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # If any rows are returned, username already exists
        if len(rows) > 0:
            return apology("this username is already in use")

        # Make sure submitted passwords are the same
        if password != request.form.get("confirmation"):
            return apology("passwords do not match")

        # Make sure password satisfies criteria: at least 8 characters, at least one capital, one lowercase, and one number
        if not (any(s.isupper() for s in password) and any(s.islower() for s in password) and any(s.isdigit() for s in password) and len(password) >=8):
            return apology("password must contain at least one number, one capital, and one lowercase letter and must be at least 8 characters long")

        # Add user to database
        db.execute("INSERT INTO users (username, hash) VALUES (:username, :hashval)",
            username = request.form.get("username"), hashval = generate_password_hash(password))

        # Redirect user to home page
        return redirect("/")

    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    if request.method == "POST":
        stock = request.form.get("symbol")
        num = request.form.get("shares")

        # Make sure symbol was selected
        if not stock:
            return apology("No stock was selected", 403)

        # Make sure text was entered in the shares field
        elif not num:
            return apology("You must input a number of shares", 403)

        # check for non-integer or negative number of shares
        if not num.isdigit():
            return apology("you must provide a non-negative integer number of stocks", 403)

        num = int(num)

        # get current shares for selected stock
        curStock = db.execute("SELECT shares FROM stocks WHERE id = :id and stock = :stock", id = session["user_id"], stock = stock)[0]["shares"]

        # check if user has enough shares
        if num > curStock:
            return apology("You don't have enough shares of this stock", 403)

        # get current price of stock
        price = lookup(stock)["price"]

        # get current cash
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])[0]["cash"]

        # added value from sold stock
        cost = price * num

         # make transaction in transaction table
        db.execute("INSERT INTO transactions ('id', 'cash0', 'stock', 'cash', 'number', 'price', 'time') VALUES (:id, :cash0, :stock, :cash, :number, :price, datetime('now'))",
            id = session["user_id"], cash0 = cash, stock = stock, cash = cash + cost, number = num, price = price)

        # update cash in user table
        db.execute("UPDATE users SET cash = :cashnew WHERE id = :id", cashnew = cash + cost, id = session["user_id"])

        # delete entry from stock table if no shares left, update otherwise
        if num == curStock:
            db.execute("DELETE FROM stocks WHERE id = :id and stock = :stock", id = session["user_id"], stock = stock)
        else:
            db.execute("UPDATE stocks SET shares = :newshares WHERE id = :id and stock = :stock", newshares = curStock - num, id = session["user_id"], stock = stock)

        return redirect("/")

    else:
        stocks = db.execute("SELECT stock FROM stocks WHERE id = :id", id = session["user_id"])
        return render_template("sell.html", stocks=stocks)

def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)