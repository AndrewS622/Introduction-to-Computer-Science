document.querySelector('select').onchange = function() {
    let textList = document.querySelectorAll('p');
    for (text = 0; text < textList.length; text++) {
        textList[text].style.fontSize = this.value;
    }

}