function greet()
{
    let name = document.querySelector('#name').value;
    if (name === '')
    {
        name = "world"
    }
    alert("Hello, " + name + "!");
    document.querySelector('#result').innerHTML = "Hello, " + name + "!";
}
function blink() {
    let head = document.querySelector('.blink');
    if (head.style.visibility == 'hidden'){
        head.style.visibility = 'visible';
    }
    else {
        head.style.visibility = 'hidden';
    }
}

window.setInterval(blink, 500);

