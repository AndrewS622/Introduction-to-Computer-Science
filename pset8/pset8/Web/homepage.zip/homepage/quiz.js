// adapted from https://www.sitepoint.com/simple-javascript-quiz/

function buildQuiz() {
    const output = [];

    // iterate through questions
    myQuestions.forEach(
        (currentQuestion, questionNumber) => {
            const answers = [];

            // iterate through answer choices
            for(letter in currentQuestion.answers){

                // add HTML radio button
                answers.push(
                    `<label>
                    <input type="radio" name="question${questionNumber}" value="${letter}">
                    ${letter}:
                    ${currentQuestion.answers[letter]}
                    </label>`
                );
            }

            // add question and answers to output
            output.push(
                `<div class="question"> <b>${currentQuestion.question} </b></div>
                <div class="answers"> ${answers.join("<br />")}</div>`
            );
        }
    );

    // combine output list into one HTML string
    quizContainer.innerHTML = output.join('');
}

function showResults() {

    // get answers
    const answerContainers = quizContainer.querySelectorAll('.answers');

    // keep track of correct
    let numCorrect = 0;

    // iterate over questions
    myQuestions.forEach((currentQuestion, questionNumber) => {
        // find correct answer
        const answerContainer = answerContainers[questionNumber];
        const selector = `input[name=question${questionNumber}]:checked`;
        const userAnswer = (answerContainer.querySelector(selector) || {}). value;

        // increment counter if correct
        if(userAnswer == currentQuestion.correctAnswer){
            numCorrect++;

            answerContainers[questionNumber].style.color = 'blue';
        }

        else{
            answerContainers[questionNumber].style.color = 'red';
        }
    });

    if(numCorrect == myQuestions.length) {
        resultsContainer.innerHTML = `${numCorrect} out of ${myQuestions.length}<br>
        Excellent job!`;
    }
    else {
        resultsContainer.innerHTML = `${numCorrect} out of ${myQuestions.length}`;
    }
}

const quizContainer = document.getElementById('quiz');
const resultsContainer = document.getElementById('results');
const submitButton = document.getElementById('submit');
const myQuestions = [
    {
        question: "Where did I grow up?",
        answers: {
            a: "Boston",
            b: "New York",
            c: "California",
            d: "Chicago",
            e: "None of the above"
        },
        correctAnswer: "b"
    },
    {
        question: "Where did I go to college?",
        answers: {
            a: "Stony Brook University",
            b: "Binghampton University",
            c: "Yale University",
            d: "UC Berkeley",
            e: "Two or more of the above"
        },
        correctAnswer: "a"
    },
    {
        question: "Where did I go to graduate school?",
        answers: {
            a: "Harvard University",
            b: "Columbia University",
            c: "Stony Brook University",
            d: "MIT",
            e: "Two or more of the above"
        },
        correctAnswer: "e"
    },
    {
        question: "What did I do in high school?",
        answers: {
            a: "Played soccer",
            b: "Competed on the debate team",
            c: "Was school president",
            d: "Built robots",
            e: "None of the above"
        },
        correctAnswer: "d"
    },
    {
        question: "What technique(s) did I use during my undergraduate research at Stony Brook University?",
        answers: {
            a: "Calcium Imaging",
            b: "X-ray crystallography",
            c: "Fluorescence Microscopy",
            d: "Nanoindentation",
            e: "a and b",
            f: "a and c",
            g: "b and c"
        },
        correctAnswer: "f"
    },
        {
        question: "What did I major in during undergrad?",
        answers: {
            a: "Mathematics and physics",
            b: "Biomedical engineering and psychology",
            c: "Materials science and computer science",
            d: "Engineering science and applied mathematics",
            e: "Chemistry and music"
        },
        correctAnswer: "d"
    },
    {
        question: "What property was I interested in during my graduate studies at Stony Brook?",
        answers: {
            a: "Cycles to failure",
            b: "Dynamic modulus",
            c: "Activation volume",
            d: "Bending stiffness",
            e: "None of the above"
        },
        correctAnswer: "c"
    },
    {
        question: "What was the main drawback of the mesh electronics I worked with at Harvard?",
        answers: {
            a: "Low channel counts",
            b: "Incapable of interfacing with non-planar tissue",
            c: "Too flexible",
            d: "Poor biocompatibility",
            e: "Nothing"
        },
        correctAnswer: "a"
    },
    {
        question: "What field am I interested in going into?",
        answers: {
            a: "Data science",
            b: "Pharmaceuticals",
            c: "Electrical engineering",
            d: "Aerospace engineering",
            e: "Medicine"
        },
        correctAnswer: "b"
    },
    {
        question: "What do I like to do in my free time?",
        answers: {
            a: "Play guitar",
            b: "Skateboard",
            c: "Run",
            d: "Write poems",
            e: "Go to concerts"
        },
        correctAnswer: "e"
    }
    ];

buildQuiz();

submitButton.addEventListener('click', showResults);